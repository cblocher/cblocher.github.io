# Content Type Catalog

This reference provides structure, format, and default guidelines for each
content type, organized by when they typically appear in a SaaS or software
project lifecycle. Use it after gathering context (Step 1 in SKILL.md).
A client style guide always overrides the defaults here.

Each content type includes a **Default Guidelines** section. These apply when
the client has not provided their own style guide or specific instructions
for that content type.

## Project Lifecycle Overview

Content types are organized into six phases. In practice, these phases
overlap — you may be writing user stories for one feature while documenting
another and maintaining help articles for a third. But understanding the
typical sequence helps you prioritize and ensures you're creating the right
content at the right time.

```
Phase 1: Discovery & Strategy
    ↓
Phase 2: Planning & Definition
    ↓
Phase 3: Design & Prototyping
    ↓
Phase 4: Build & Document
    ↓
Phase 5: Launch & Announce
    ↓
Phase 6: Operate & Maintain
    ↓
(cycle repeats for next feature/release)
```

## Table of Contents

1. Discovery & Strategy — content strategy, style guides, word lists/glossaries
2. Planning & Definition — PRDs, feature specs, user stories, acceptance criteria
3. Design & Prototyping — UX flows, wireframe annotations, content/label
   guidelines, microcopy, error messages, onboarding copy, empty states
4. Build & Document — API references, SDK guides/tutorials, help articles,
   user guides, compliance documentation
5. Launch & Announce — release notes, changelogs, blog posts, emails,
   social media posts, campaigns, video scripts, thumbnail copy,
   captions/subtitles
6. Operate & Maintain — FAQs, knowledgebase/troubleshooting articles

## Localization Principles (Apply to All Phases)

Keep localization in mind from the start — not as an afterthought. Content
that will be translated or read by a global audience needs to be written
with care. These principles apply across every content type in this catalog.

**Writing for translation:**
- Use short, direct sentences. Complex sentence structures are harder and
  more expensive to translate accurately.
- Avoid idioms, slang, colloquialisms, and culturally specific humor.
  "Piece of cake" doesn't translate. "This is straightforward" does.
- Avoid phrasal verbs when a single verb works ("find out" → "discover,"
  "set up" → "configure," "turn on" → "enable").
- Don't embed text in images — it can't be translated without recreating
  the image.
- Leave room for text expansion. Translated text is often 20–30% longer
  than English. Design UI copy and layouts with this in mind.

**Terminology consistency:**
- Use one term for one concept. Synonyms create confusion for translators
  and readers. If it's "workspace" in one article, don't call it "project
  space" in another.
- Maintain a glossary with approved translations for key terms if the
  content is translated into specific target languages.
- Flag terms that should not be translated (product names, feature names,
  branded terms).

**Cultural sensitivity:**
- Avoid assumptions about date formats, currency, measurement units,
  or address structures. Use ISO 8601 for dates in technical content
  (YYYY-MM-DD). Spell out month names in user-facing content
  (February 16, 2026) to avoid ambiguity.
- Don't assume left-to-right reading order in designs or flow descriptions.
- Avoid references that only make sense in one culture or region
  (sports metaphors, holidays, legal frameworks).
- Be mindful of color symbolism — colors carry different meanings in
  different cultures.

---

## Phase 1: Discovery & Strategy

This is where the foundation is set. Before any feature is built or any
user-facing content is written, establish the rules, terminology, and
strategic direction that everything else will follow. Content created in
this phase is referenced throughout the entire project lifecycle.

### Content Strategy Documents

**Purpose:** Define the plan for content across a product or organization.

**Conventions:**
- State the goals, audience, and channels clearly
- Include a content audit or inventory if relevant
- Define governance: who creates, reviews, and maintains content
- Include a content lifecycle (creation → review → publish → maintain → retire)

**Default guidelines (when no client guide exists):**
- Include a localization strategy section if the product serves multiple
  markets or languages
- Define content ownership by area or feature
- Include a measurement plan (what metrics define content success)
- Plan for content maintenance — who reviews, how often, what triggers a rewrite

### Style Guides

**Purpose:** Define voice, tone, grammar, and formatting standards for a team
or product.

**Structure:**
- Voice and tone principles (with examples of each)
- Grammar and punctuation rules
- Terminology / word list (preferred terms and terms to avoid)
- Formatting standards (headings, lists, code, UI references)
- Accessibility guidelines
- Localization guidelines (terms not to translate, text expansion guidance,
  cultural considerations)
- Examples of content at different tone levels (e.g., error vs. success vs.
  marketing)

**Default guidelines (when no client guide exists):**
- Include at least one "do this / not this" example for each major rule
- Organize by topic (voice, grammar, formatting) not by content type
- Keep it under 20 pages; a style guide nobody reads is useless
- Include a quick-reference summary on one page for daily use
- Review and update annually at minimum

### Word Lists and Glossaries

**Purpose:** Ensure consistent, inclusive terminology across all content.

**Structure:**
- Alphabetical listing
- Each entry: Term, definition, usage notes (when to use, when not to use)
- Flag terms that differ between audiences (e.g., "workspace" for users,
  "organization" for API)
- Flag terms that should not be translated (product names, branded features)

**Insensitive language guidance:**

Word lists and glossaries should actively identify and replace insensitive
or exclusionary language. When creating or reviewing a word list, flag terms
that may be harmful, exclusionary, or rooted in biased metaphors, and provide
preferred alternatives.

Common categories to review:

- **Ableist language:** Avoid terms that use disability as a negative metaphor.
  "Crippled" → "degraded" or "reduced." "Sanity check" → "confidence check"
  or "validation check." "Blind spot" → "oversight" or "gap."
- **Racially charged language:** "Blacklist/whitelist" → "blocklist/allowlist."
  "Master/slave" → "primary/replica" or "controller/worker."
  "Grandfathered" → "legacy" or "pre-existing."
- **Gendered language:** "Manpower" → "workforce" or "staffing."
  "Man-hours" → "person-hours" or "labor hours." "Guys" (when addressing
  a group) → "everyone," "team," "folks."
- **Violent or aggressive metaphors:** "Kill the process" → "stop the process"
  or "end the process." "Nuke the database" → "delete the database" or
  "reset the database." "Execute" → "run" (in technical contexts where
  "execute" carries violent connotation for the audience).
- **Age-based and othering language:** "Elderly" → "older adults."
  "Normal users" → "typical users" or just "users."

When adding a term to the word list:
- State the term to avoid
- Explain briefly why it's problematic (one sentence is enough)
- Offer 1–2 preferred alternatives
- Note any exceptions (e.g., when the term is part of a proper noun or
  industry-standard protocol name that can't be changed)

**Default guidelines (when no client guide exists):**
- Start with the inclusive language review above for any new word list
- Include pronunciation guidance for terms that are commonly mispronounced
  (especially product names and acronyms)
- Note regional spelling differences if the content serves multiple English
  markets (e.g., "color" vs. "colour," "organize" vs. "organise")
- Update the word list whenever new features, products, or terminology
  are introduced
- Review for insensitive language at least twice a year

---

## Phase 2: Planning & Definition

This is where the product team defines what's being built and why. Content
created here drives engineering, design, and QA — and serves as the source
of truth for what the feature should do. Getting the language right at this
stage prevents terminology conflicts, scope creep, and miscommunication
downstream.

### Product Requirements Documents (PRDs)

**Structure:**
- Problem statement: What problem are we solving, and for whom?
- Goals and success metrics: How will we know this worked?
- Scope: What's in and what's out
- User stories or use cases
- Requirements (functional and non-functional)
- Dependencies and risks
- Timeline and milestones

**Default guidelines (when no client guide exists):**
- Start with the user problem, not the solution
- Include a one-paragraph executive summary at the top
- Define success metrics that are specific and measurable
- List assumptions explicitly — don't leave them implied
- Include localization requirements if the feature will serve multiple markets
  (language support, date/number formatting, right-to-left layout needs)

### Feature Specs

**Structure:**
- Feature name and owner
- User story: "As a [role], I want [capability] so that [benefit]"
- Detailed requirements
- Edge cases and error states
- Acceptance criteria (see below)
- Design references (links to mockups/wireframes)

**Default guidelines (when no client guide exists):**
- Include content requirements: what strings, labels, messages, and
  notifications does this feature need?
- Note any localization implications (new strings to translate, cultural
  considerations, character limit impacts from text expansion)
- Define the error states and their messages as part of the spec, not
  as an afterthought
- List every user-visible string so the content team can review them

### User Stories and Acceptance Criteria

**User story format:**
"As a [type of user], I want [action] so that [outcome]."

**Acceptance criteria format (Given/When/Then):**
- Given [context], when [action], then [expected result].
- Cover the happy path, edge cases, and error states.
- Each criterion should be independently testable.

**Default guidelines (when no client guide exists):**
- Write user stories from the user's perspective, not the system's
- Keep each story small enough to complete in one sprint
- Include at least 3 acceptance criteria per story: happy path, one edge
  case, one error state
- Avoid technical implementation details in user stories; save those for
  the spec

---

## Phase 3: Design & Prototyping

This is where the user experience takes shape. Content created here is the
actual copy that users will see in the product — buttons, labels, error
messages, onboarding screens, empty states. Writing this content during
design (not after) ensures it's part of the experience, not bolted on later.

### UX Flows and Wireframe Annotations

**Purpose:** Describe what happens at each step of a user journey.

**Conventions:**
- Label every screen or state
- Describe the user's goal at each step
- Note decision points and branching paths
- For wireframe annotations: label UI elements with the actual copy that
  should appear, not placeholder text
- Include error states and empty states

**Default guidelines (when no client guide exists):**
- Number each screen or state for easy reference in reviews
- Include the actual UI copy in annotations — not "lorem ipsum" or
  "TBD" — even if it's a draft
- Note where content will need to accommodate text expansion for
  localized versions
- Call out any screens that require right-to-left layout variants

### Content and Label Guidelines

**Purpose:** Provide specific copy guidance for a product's UI.

**Conventions:**
- Organize by feature area or screen
- For each element: state the label, helper text, placeholder text, and
  any validation messages
- Note character limits if relevant
- Include rationale for naming decisions when it helps maintain consistency

**Default guidelines (when no client guide exists):**
- Include all user-visible strings: labels, buttons, tooltips, helper text,
  placeholder text, validation messages, confirmation messages, empty states
- Note maximum character counts, especially for elements that will be
  translated
- Provide the context for each string (where it appears, what it does)
  so translators can produce accurate translations
- Flag any strings that contain variables or dynamic content and explain
  what values they can take

### Microcopy (Buttons, Labels, Tooltips)

**Purpose:** Guide the user through the interface with minimal, clear text.

**Conventions:**
- Buttons: Start with a verb. Be specific. "Save changes" not "Submit."
  "Create account" not "Go."
- Labels: Use nouns. Match the user's mental model, not the data model.
  "Email address" not "email_field."
- Tooltips: One sentence explaining what the element does or why it's there.
  Don't repeat the label.
- Keep it short. If you need more than a sentence, it belongs in help content,
  not the UI.
- Use sentence case, not title case (unless the client guide specifies otherwise)

**Default guidelines (when no client guide exists):**
- Buttons: 1–4 words. Verb + noun ("Save changes," "Add member," "Download report")
- Labels: Match the term used in the help documentation — don't invent new names
- Tooltips: Under 150 characters. Start with a verb or "The..." — not "This is..."
- Placeholder text: Show the expected format ("name@example.com") not instructions
  ("Enter your email")
- Account for text expansion (translated strings may be 30% longer)

### Error Messages

**Purpose:** Tell the user what went wrong, why, and what to do next.

**Structure:**
1. What happened (in plain language)
2. Why it happened (if it helps the user)
3. What to do next (a clear action)
4. Escalation path (if the action doesn't work)

**Conventions:**
- Don't blame the user ("Your input is invalid" → "Enter a valid email address")
- Don't use technical jargon in user-facing errors (no stack traces, no hex codes)
- Use a human-readable reference code if support needs a technical identifier
- Keep the tone calm and helpful, not alarming

**Default guidelines (when no client guide exists):**
- Maximum 2 sentences for inline validation errors
- Maximum 3 sentences for page-level or modal errors
- Always include a recovery action — never leave the user at a dead end
- Use the pattern: "[What went wrong]. [What to do next]."
- Don't use "please" more than once per error; it becomes noise

### Onboarding Copy

**Purpose:** Help new users get started and reach their first success quickly.

**Conventions:**
- Focus on one thing at a time; don't overwhelm
- Celebrate progress ("You're all set!" not just "Setup complete.")
- Write for someone who has never seen the product before
- Every screen should answer: "What do I do here, and why?"

**Default guidelines (when no client guide exists):**
- Limit each screen to one task or decision
- Use progressive disclosure — don't show everything at once
- Headline: what the user will accomplish. Subtext: why it matters.
- Keep total onboarding to 3–5 screens unless complexity demands more
- Include a skip option for non-essential steps

### Empty States

**Purpose:** Guide the user when there's no content to display yet.

**Conventions:**
- Explain what will appear here once they take action
- Include a clear call to action ("Create your first project")
- Keep the tone encouraging, not empty ("No projects yet" → "Create your first
  project to get started")

**Default guidelines (when no client guide exists):**
- Structure: Heading + 1 sentence of context + primary action button
- Don't just say what's missing — tell the user what to do about it
- If the empty state isn't the user's fault (e.g., no search results),
  offer alternative paths ("Try a different search term" or "Browse categories")

---

## Phase 4: Build & Document

This is where the feature is being developed and the supporting documentation
is written alongside it. Help articles, user guides, API references, and
developer tutorials should be drafted in parallel with engineering — not
saved for the end. Compliance documentation also typically takes shape here,
as controls and processes are formalized.

### API References

**Purpose:** Provide a complete, precise description of every endpoint.

**Structure per endpoint:**
- HTTP method and path: `GET /v1/users`
- Description: One sentence starting with a verb ("Returns a paginated list of...")
- Authentication: What's required
- Parameters: Table with name, type, required/optional, description
- Request example: A realistic, working example with curl or SDK
- Response example: The actual JSON shape with realistic data
- Response fields: Table describing each field
- Error responses: Status codes, error shapes, and what triggers them
- Rate limits (if applicable)

**Conventions:**
- Be precise about types (string, integer, ISO 8601 datetime — not just "date")
- Every example should be copy-pasteable and actually work
- Don't describe what the user "should" do; describe what the API does
- Use consistent terminology for the same concept across all endpoints

**Default guidelines (when no client guide exists):**
- Use OpenAPI/Swagger conventions for structure and naming
- Include at least one complete request/response pair per endpoint
- Document every error code the endpoint can return
- Use realistic (but fake) data in examples — not "foo," "bar," or "test"
- Note required headers explicitly; don't make developers guess

### SDK Guides and Tutorials

**Purpose:** Walk a developer through building something with your tool.

**Structure:**
- What you'll build (outcome-first)
- Prerequisites: Language version, packages, API keys
- Steps with code: Numbered steps, each with a code block and explanation
- Complete working example at the end
- Next steps: Links to related tutorials or API reference

**Conventions:**
- Code blocks must specify the language for syntax highlighting
- Show the complete, working code — not just snippets with "..." gaps
- Explain the "why" briefly, not just the "what"
- Test every code example before publishing (flag this for the user if you can't)

**Default guidelines (when no client guide exists):**
- State the estimated completion time at the top
- List exact version numbers for all dependencies
- Include a "What you'll need" section before step 1
- End with a working, runnable example the developer can use as a starting point
- Link to the API reference for each method or endpoint used

### Help Articles

**Purpose:** Help a user complete a specific task or understand a feature.

**Structure:**
- Title: Start with a verb or "How to..." (e.g., "Set up two-factor authentication")
- Brief intro: 1–2 sentences explaining what this article covers and why it matters
- Prerequisites (if any): What the user needs before starting
- Steps: Numbered, one action per step, starting with a verb
- Expected result: What the user should see when they're done
- Troubleshooting (if relevant): Common issues and fixes
- Related articles (if relevant): Links to next steps or related tasks

**Conventions:**
- Write in second person ("you")
- Use the present tense
- Bold UI element names (buttons, menu items, page names)
- Use "select" instead of "click" (device-agnostic)
- Keep each step to one action; if a step has "and" in it, split it

**Default guidelines (when no client guide exists):**
- Aim for a grade 6–8 reading level
- Maximum 7–10 steps per procedure; if longer, break into sub-tasks
- Include "before you begin" prerequisites when the task has dependencies
- End with a confirmation step so the user knows they succeeded
- Keep articles focused on one task; don't combine multiple procedures

### User Guides

**Purpose:** Teach a user how to use a feature or product area in depth.

**Structure:**
- Title and overview
- Key concepts (define terms the reader needs)
- Sections organized by task or workflow, not by UI layout
- Examples or scenarios showing real-world usage
- Tips or best practices
- Next steps or related guides

**Conventions:**
- Longer than help articles but still scannable
- Use headings to break up sections (the reader should be able to skip to what they need)
- Include screenshots or diagrams only if they clarify something text can't

**Default guidelines (when no client guide exists):**
- Open with a 2–3 sentence overview that tells the reader what this guide
  covers and who it's for
- Define every term on first use, even if it seems obvious
- Use real-world scenarios instead of abstract descriptions
- Include a "What's next?" section at the end
- If the guide exceeds 2,000 words, add a table of contents

### Compliance Documentation (SOC2, ISO, etc.)

**Purpose:** Describe controls, policies, and procedures for audit purposes.

**Conventions:**
- Use the exact language required by the framework where specified
- Be precise and verifiable — every claim should be traceable to evidence
- Organize by control domain or framework section
- Avoid marketing language; auditors want facts, not persuasion
- Date everything and note review cycles

**Default guidelines (when no client guide exists):**
- Mirror the framework's structure and numbering exactly
- Use the present tense for current controls ("The system logs all access events")
- Include evidence references for each control statement
- Separate policy (what we do) from procedure (how we do it)
- Include a revision history table with date, author, and change summary
- Have a legal or compliance reviewer approve before publishing

---

## Phase 5: Launch & Announce

This is where you tell the world what's new. Content created here
communicates the value of what was built, drives adoption, and sets
expectations. The audience shifts outward — from internal teams to
customers, prospects, developers, and the broader market.

### Release Notes

**Purpose:** Communicate what's new to a broader audience (often less technical
than a changelog).

**Structure:**
- Headline summarizing the theme of the release
- Key highlights (2–3 sentences each for major features)
- Improvements and fixes (briefer)
- Known issues (if any)
- How to get started or upgrade

**Conventions:**
- Lead with value: what can the user do now that they couldn't before?
- Use screenshots or GIFs for visual features
- Link to full documentation for details

**Default guidelines (when no client guide exists):**
- Write for the end user, not the engineering team
- Open with one sentence that captures the release theme
- Limit to 3–5 highlights; link to the changelog for the complete list
- Include a "Getting started" or "How to update" section
- Date the release notes clearly

### Changelogs

**Purpose:** Inform users (often developers) about what changed in each release.

**Structure:**
- Version number and date
- Grouped by type: Added, Changed, Fixed, Deprecated, Removed, Security
- Each entry: One sentence describing the change and its impact
- Link to relevant docs or migration guides for breaking changes

**Conventions:**
- Write in past tense ("Added support for..." not "Adds support for...")
- Be specific ("Fixed a bug where CSV exports included deleted records"
  not "Fixed export bug")
- Call out breaking changes prominently

**Default guidelines (when no client guide exists):**
- Follow the Keep a Changelog format (https://keepachangelog.com)
- Date format: YYYY-MM-DD
- One line per change; link to the relevant issue or pull request if public
- Breaking changes go at the top of their section, prefixed with **BREAKING:**
- Include migration steps or link to a migration guide for any breaking change

### Blog Posts and Emails

**Purpose:** Inform, educate, or engage an audience.

**Conventions:**
- Follow the client's brand voice closely (this varies the most across clients)
- For technical blog posts: start with the problem, then the solution,
  then the details
- For emails: frontload the most important information; many readers only
  see the first few lines
- Include a clear call to action when appropriate

**Default guidelines (when no client guide exists):**
- Blog posts: 800–1,500 words for standard posts. Open with the problem
  or question. Use subheadings every 200–300 words. End with a call to action
  or next step.
- Emails: Keep the subject line under 50 characters. Lead with the single
  most important point. One call to action per email. Limit to 200–300 words
  for transactional emails; 500–800 for newsletters.
- For both: write a meta description (under 160 characters) and suggest
  a social sharing summary.

### Social Media Posts

**Purpose:** Share updates, promote content, engage an audience, or drive action
on social platforms.

**Conventions:**
- Match the platform's conventions and character limits (see defaults below)
- Write in the client's brand voice; social is where voice matters most
- Every post should have a clear purpose: inform, engage, or drive to a link
- Use plain language — social audiences scan quickly
- Avoid jargon unless the audience expects it (developer communities, for example)
- Include alt text for every image
- Add captions or subtitles to all video content

**Default guidelines (when no client guide exists):**

- **X/Twitter:** Under 280 characters. Lead with the hook. One link max.
  Use 1–3 relevant hashtags, not more.
- **LinkedIn:** 1–3 short paragraphs. Professional but not stiff. First line
  is critical — it shows before the "see more" fold. Use line breaks for
  readability. Tag relevant people or companies when appropriate.
- **Instagram:** Caption under 2,200 characters; front-load the key message
  in the first 125 characters (before the fold). Use 3–5 targeted hashtags
  in the caption or first comment. Write alt text for every image. For
  carousels: treat each slide as a self-contained point with minimal text
  overlay. For Reels: see Video Scripts below.
- **Facebook:** 1–3 short paragraphs. Conversational tone. First 1–2
  sentences should work as a standalone hook since most users won't expand.
  Native video and images outperform link posts — lead with media when
  possible. Include a clear call to action.
- **TikTok:** Captions under 4,000 characters, but shorter is better — most
  viewers won't read long captions. The hook is in the video, not the text.
  Use 3–5 relevant hashtags. Write captions that complement the video rather
  than repeat it. See Video Scripts below for the video itself.
- **Pinterest:** Write pin titles under 100 characters and descriptions under
  500 characters. Front-load keywords; Pinterest functions as a visual search
  engine, so discoverability depends on clear, specific language. Describe
  what the pin shows and what the reader will get if they click (e.g., "Step-
  by-step guide to setting up SSO" not "Great article about security").
  Use 2–5 relevant keywords naturally in the description. For Idea Pins
  (multi-page): treat each page as a self-contained point with minimal text
  overlay, similar to Instagram carousels. Write alt text for every image.
  Link pins to the source content whenever possible.
- **YouTube:** See Video Scripts and Thumbnail Copy below for the primary
  content. For Community posts: keep them conversational, use polls to drive
  engagement, and keep text concise.
- **Mastodon / Bluesky / Threads:** Follow the platform's culture — less
  promotional, more conversational. Respect character limits.

**General defaults across all platforms:**
- Don't start with "We're excited to announce..." or "We're thrilled to
  share..." — start with what matters to the reader. State the value or
  news first.
- Use hashtags sparingly. Research whether they help or hurt engagement
  on the specific platform.
- Every image needs alt text. Every video needs captions.
- Adapt the message to each platform's format and culture — don't cross-post
  identical copy.

### Social Media Campaigns

**Purpose:** Coordinate a series of posts around a launch, event, or theme.

**Structure:**
- Campaign goal (awareness, signups, engagement, traffic)
- Audience and platform(s)
- Key message or theme (one sentence)
- Post schedule with dates, platforms, and draft copy for each post
- Visual direction and content format per platform (static, carousel,
  video, Reel, Story)
- Video/animation requirements (if applicable): scripts, thumbnail copy,
  caption files
- Metrics to track

**Default guidelines (when no client guide exists):**
- Define one primary message for the campaign — every post should reinforce it
- Vary the format across posts (text-only, image, carousel, video, poll,
  thread, Story, Reel)
- Don't repeat the same copy across platforms; adapt to each one's format
  and culture
- Plan for engagement — prepare responses to likely comments or questions
- Include accessible descriptions for all visual content
- For video-heavy campaigns: write scripts, thumbnail copy, and caption
  files as part of the deliverable, not as afterthoughts

### Video Scripts

**Purpose:** Provide the spoken and on-screen text for product videos, tutorials,
explainers, social Reels/Shorts/TikToks, and animations.

**Structure:**
- Title and format (tutorial, explainer, product demo, social short,
  animated walkthrough)
- Target platform(s) and length
- Audience
- Hook (first 3–5 seconds — what stops the scroll or keeps the viewer watching)
- Script body: two-column format with visual direction on the left and
  spoken/on-screen text on the right
- Call to action (what the viewer should do after watching)
- On-screen text overlays (exact copy, placement notes, timing)

**Conventions:**
- Write for the ear, not the eye. Read the script aloud — if it sounds
  awkward spoken, rewrite it.
- Keep sentences short. One idea per sentence.
- Front-load the value — state what the viewer will learn or gain in the
  first 5 seconds.
- For tutorials: match the script to the on-screen action step by step.
  Don't describe something that happens 10 seconds later.
- For animations: include timing cues and describe what should appear
  on screen at each beat.

**Default guidelines (when no client guide exists):**
- **Short-form (TikTok, Reels, YouTube Shorts):** 15–60 seconds. Hook in
  the first 2–3 seconds. One topic per video. End with a clear next step
  (follow, comment, visit link). On-screen text should be readable in 2–3
  seconds per line. Use large, high-contrast text.
- **Mid-form (product demos, feature explainers):** 1–3 minutes. Open with
  the problem, show the solution, end with the benefit. Include chapter
  markers or timestamps for navigation.
- **Long-form (tutorials, webinars, walkthroughs):** 5–20 minutes. Include
  a table of contents or chapter list. Break into clear sections. Summarize
  key points at the end.
- **Animations and motion graphics:** Write a beat sheet (one line per visual
  beat) before the full script. Note transitions, timing, and any text that
  appears on screen. Specify duration for each text overlay.
- For all formats: write captions/subtitles as a separate deliverable.
  Don't assume the viewer can hear the audio.

### Thumbnail Copy

**Purpose:** Write the text that appears on video thumbnails to drive clicks.

**Conventions:**
- Maximum 3–6 words. The text must be readable at thumbnail size.
- Create contrast with the image — don't repeat the video title exactly.
  The thumbnail text and title should complement each other.
- Use high-contrast, large text. Avoid thin fonts or low-contrast colors.
- Don't clutter — one short phrase is better than two.

**Default guidelines (when no client guide exists):**
- **YouTube:** Thumbnail text should tease the payoff or create curiosity.
  Avoid clickbait — the text should accurately represent the content.
  Test readability at mobile size (the smallest size most viewers will see).
- **Course or tutorial thumbnails:** State the outcome, not the topic.
  "Build a Dashboard" not "Dashboard Tutorial." Use numbered formats when
  part of a series ("Part 3: API Auth").
- For all platforms: provide 2–3 thumbnail text options so the designer
  or creator can choose what works best with the image.

### Captions and Subtitles

**Purpose:** Provide text alternatives for spoken audio in video content.

**Conventions:**
- Captions should be verbatim to the spoken audio (not paraphrased)
- Include speaker identification when multiple people are speaking
- Note relevant non-speech sounds in brackets: [applause], [music],
  [screen transition]
- Keep each caption line to 1–2 lines on screen, under 42 characters per line
- Time captions to match the audio — don't display them too early or late

**Default guidelines (when no client guide exists):**
- Deliver captions as an SRT or VTT file alongside the video script
- For auto-generated captions: always review and correct before publishing.
  Automated captions frequently mishandle product names, technical terms,
  and proper nouns.
- Include captions for all video content, not just long-form. Social shorts,
  Reels, and TikToks need captions too — many viewers watch without sound.
- If the content will be localized, provide the caption file as a separate
  deliverable so it can be translated independently of the video

---

## Phase 6: Operate & Maintain

After launch, the focus shifts to supporting users, answering questions,
and solving problems. Content created here is reactive — driven by real
user behavior, support tickets, and product changes. This phase also
includes ongoing maintenance of all content created in earlier phases:
reviewing for accuracy, updating after product changes, and retiring
content that's no longer relevant.

### FAQs

**Purpose:** Answer common questions quickly.

**Structure:**
- Questions phrased as the user would ask them (natural language)
- Answers that are direct and concise — answer first, explain after
- Group by topic if there are many questions
- Link to full articles for complex answers rather than duplicating content

**Conventions:**
- Avoid the temptation to write long answers; if it takes more than a short
  paragraph, it should be its own help article
- Keep questions consistent in style (all start with "How do I..." or "What is...")

**Default guidelines (when no client guide exists):**
- Lead each answer with a direct, one-sentence response, then elaborate
- Limit each answer to 3–5 sentences maximum
- Use the same phrasing the user would — not internal product jargon
- Review and update FAQs quarterly; stale FAQs erode trust

### Knowledgebase / Troubleshooting Articles

**Purpose:** Help a user diagnose and resolve a problem.

**Structure:**
- Title: Describe the symptom, not the cause ("App won't load after update"
  not "Cache invalidation error")
- Symptoms: What the user is experiencing
- Cause (if known): Brief explanation
- Solution: Step-by-step fix
- Workaround (if the fix is complex): A quicker temporary option
- If this doesn't work: Escalation path (contact support, file a ticket)

**Default guidelines (when no client guide exists):**
- Title should match what a user would type into a search bar
- Describe symptoms in the user's language, not engineering terms
- Provide the fastest fix first, then alternatives
- Include the product version or environment if the issue is version-specific
- Date the article so users know whether the information is current

### Ongoing Content Maintenance

This isn't a content type — it's a practice. All content created in
Phases 1–5 needs regular review and maintenance. Without it, documentation
drifts out of sync with the product and becomes a liability instead of
an asset.

**Maintenance triggers:**
- A feature changes or is deprecated
- A support ticket reveals a gap or inaccuracy in existing content
- A new feature launches that affects existing workflows
- Terminology changes (rebranding, updated word list)
- Scheduled review cycle (quarterly for high-traffic content, annually
  for everything else)

**Maintenance actions:**
- Update screenshots, steps, and terminology to match the current product
- Remove or redirect content for deprecated features
- Consolidate duplicate content — if two articles cover the same topic,
  merge them
- Review metadata and taxonomy — does the content still belong where
  it's categorized?
- Check that all links still work and point to the right destination
- Update the "last reviewed" date after every review, even if no changes
  were made
