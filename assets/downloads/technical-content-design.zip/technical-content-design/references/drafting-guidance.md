# Drafting Guidance Reference

This reference provides detailed guidance for three areas of the drafting
process (Step 2 in SKILL.md): applying DITA semantic patterns, flagging
reuse candidates, and recommending visuals.

## DITA Semantic Patterns

When generating content, consider the most applicable patterns from the
DITA semantic stack. You don't need to output DITA XML (unless the user's
tooling requires it), but the principles behind DITA's architecture should
shape how you think about structure, reuse, and relationships:

- **Topic types (structure):** Is this content a concept (explains what
  something is), a task (explains how to do something), or a reference
  (provides lookup information)? Structure the content according to its
  type. Don't mix a procedural task with a conceptual explanation in a
  single section; separate them into distinct, focused units.
- **Specialization (extensibility):** If the content type doesn't fit
  neatly into concept, task, or reference, identify the closest base type
  and extend it. A troubleshooting article is a specialized task. A
  glossary entry is a specialized reference.
- **Reuse (efficiency):** Author modular content that can be reused across
  deliverables. See "Flagging Reuse Candidates" below for specifics.
- **Maps (architecture):** Think about how individual content pieces
  assemble into a larger structure. A help center is a map of topics. A
  user guide is a map of concepts, tasks, and references in a deliberate
  sequence. Consider the map even when writing a single topic.
- **Metadata (meaning):** Every piece of content should carry metadata
  that makes it findable, filterable, and classifiable. See the taxonomy,
  ontology, and metadata guidance in Step 3 of SKILL.md.
- **Profiling (personalization):** Consider whether the content needs to
  vary by audience, platform, product tier, or role. Flag sections that
  should be conditionally included or excluded (e.g., "This step applies
  to Enterprise plans only").
- **Linking (relationships):** Define how this content connects to other
  content. Prerequisite links, related topics, next steps, and parent/child
  relationships all help the reader navigate and help machines understand
  the content graph.
- **Domains (industry semantics):** If the content uses domain-specific
  terminology (healthcare, finance, legal, engineering), apply the
  relevant domain vocabulary consistently and note it for the glossary.

---

## Flagging Reuse Candidates

While drafting, actively identify content that should be authored once and
reused everywhere it appears. Don't wait for the content to be published
and duplicated before flagging this. Call it out in your draft.

**What to flag:**
- Repeated procedures that appear in multiple articles (e.g., "Log in to
  your account," "Navigate to Settings > Account"). These are candidates
  for reusable **snippets** or **fragments** that can be maintained in one
  place and inserted wherever needed.
- Product names, feature names, and branded terms that must be consistent.
  These are candidates for **variables** so that a name change propagates
  everywhere automatically.
- Definitions that appear in more than one place. These belong in a
  **glossary** and should be referenced, not rewritten each time.
- Legal, compliance, or safety language (disclaimers, warnings, consent
  copy) that must be identical wherever it appears. Author once as a
  reusable fragment.
- UI strings that appear in both the product and the documentation. Flag
  these so the content team can keep them in sync.

**How to flag in your draft:**
- Insert a note where you spot a reuse opportunity:
  `[Reuse candidate: this procedure also appears in "Set up SSO" and
  "Manage team members." Consider a shared snippet.]`
- If the user's tooling supports variables, fragments, or content
  references (e.g., in a CMS, CCMS, or docs-as-code setup), note the
  specific mechanism. If you don't know the tooling, flag the opportunity
  and let the user decide how to implement it.

---

## Recommending Visuals (Aggressively)

Every draft should include visual recommendations. Do not wait for the user
to ask. If a section could be clearer with a visual, recommend one. Err on
the side of too many visual suggestions rather than too few.

**When to recommend visuals (always consider these):**
- Procedural steps that involve a UI: suggest annotated screenshots or a
  short screen recording / GIF showing the interaction
- Workflows or processes with branching paths: suggest a flowchart or
  decision diagram
- Conceptual relationships (how components connect, how data flows):
  suggest an architecture diagram or infographic
- Before/after comparisons: suggest side-by-side images or a short
  animation showing the change
- Complex data or comparisons: suggest a chart, table, or data visualization
- Onboarding and getting-started content: suggest a short walkthrough
  video (30-90 seconds) or animated GIF
- Feature announcements and release notes: suggest a GIF or short video
  demo showing the feature in action
- Social media posts: suggest image carousels, short video clips, or
  animated graphics appropriate to the platform
- Error states and troubleshooting: suggest a screenshot of what the
  user should see, so they can confirm they're in the right place
- Any concept that takes more than two paragraphs to explain in text:
  a visual will almost certainly help

**Generate what you can, placeholder what you can't:**
- For diagrams, flowcharts, process illustrations, charts, simple
  infographics, and SVGs: offer to generate them directly alongside the
  draft using code (SVG, HTML, Mermaid, or React). Don't leave these as
  placeholders if you can produce them.
- For screenshots, photographs, screen recordings, GIFs of live UI, and
  complex illustrations: insert `[Visual: description and format]`
  placeholders with enough detail that a designer or the user can
  produce them.

**How to recommend visuals in your drafts:**
- Insert a visual placeholder in the draft where the visual should appear,
  using this format: `[Visual: brief description of what the visual should
  show and its format, e.g., "Screenshot of the Settings > Account page
  with the Change Password button highlighted" or "15-second GIF showing
  the drag-and-drop reordering interaction"]`
- Specify the format: screenshot, annotated screenshot, diagram, flowchart,
  GIF/animation, short video, infographic, illustration, or chart
- Note whether the visual is essential (the content doesn't work without it)
  or supporting (it enhances understanding but the text can stand alone)
- For video recommendations, note the approximate length and whether it
  needs narration, captions, or on-screen text only

**Visual accessibility (always applies):**
- Every image needs descriptive alt text (WCAG 1.1.1)
- Don't rely on visuals alone to convey critical information; the text
  should be complete without them
- Animations and videos need captions or transcripts (WCAG 1.2.2)
- Avoid flashing content (WCAG 2.3.1)
- Ensure sufficient color contrast in diagrams and annotated screenshots
  (WCAG 1.4.3)
