# Accessibility Checklist (WCAG 2.1 AA)

Every piece of content must meet WCAG 2.1 AA. This is non-negotiable,
regardless of whether the client style guide mentions accessibility.
Each item below references the specific WCAG success criterion it supports
and shows how to apply it.

Run through this before finalizing any deliverable.

## Language and Readability

- Use plain language appropriate to the audience (aim for grade 8 reading
  level for end-user content; technical content can be higher but should
  still be as clear as possible).
  Supports: WCAG 3.1.5 (Reading Level).
  Example: Instead of "Utilize the authentication mechanism to validate
  your credentials," write "Sign in with your email and password."

- Use short sentences and paragraphs.
  Supports: WCAG 3.1.5 (Reading Level).

- Define acronyms and abbreviations on first use.
  Supports: WCAG 3.1.4 (Abbreviations).
  Example: "Single sign-on (SSO) lets your team sign in once to access
  all connected apps. After this first mention, use SSO."

- Avoid idioms, jargon, and culturally specific references unless the
  audience expects them.
  Supports: WCAG 3.1.3 (Unusual Words).

## Structure and Navigation

- Use a clear heading hierarchy (h1, then h2, then h3; never skip levels).
  Supports: WCAG 1.3.1 (Info and Relationships).
  Example: A page with an h1 followed directly by an h3 (skipping h2)
  breaks the hierarchy. Screen readers use heading levels to build a
  navigable outline of the page. Skipping levels makes that outline
  confusing and unreliable.

- Write descriptive headings that tell the reader what the section covers.
  Supports: WCAG 2.4.6 (Headings and Labels).
  Example: "Configure SAML settings" is descriptive. "Settings" is not.
  A screen reader user scanning headings should understand each section's
  purpose without reading the body text.

- Front-load important information in each section.
  Supports: WCAG 2.4.6 (Headings and Labels), general usability.

- Use meaningful link text (never "click here"; describe the destination).
  Supports: WCAG 2.4.4 (Link Purpose in Context).
  Example: Instead of "To learn more, click here," write "Read the
  authentication setup guide." Screen readers can list all links on a
  page; "click here" repeated five times tells the user nothing.

## Images and Media

- Provide descriptive alt text for every image (describe what the image
  conveys, not just what it shows).
  Supports: WCAG 1.1.1 (Non-text Content).
  Example: For a screenshot showing a success message after saving, write
  alt="Settings page showing a green banner that reads 'Your changes
  have been saved.'" Not alt="screenshot" or alt="settings page."

- Don't rely on color alone to communicate meaning.
  Supports: WCAG 1.4.1 (Use of Color).
  Example: If a status indicator uses red for errors and green for
  success, also include a label or icon. "Status: Error (red circle
  with X)" not just a red dot.

- Provide text alternatives for any non-text content.
  Supports: WCAG 1.1.1 (Non-text Content).

- Provide captions for video content and transcripts for audio.
  Supports: WCAG 1.2.2 (Captions, Prerecorded), 1.2.1 (Audio-only
  and Video-only, Prerecorded).

- Avoid flashing content (nothing that flashes more than three times
  per second).
  Supports: WCAG 2.3.1 (Three Flashes or Below Threshold).

## Tables and Data

- Use proper table headers (th elements, not just bold text in td cells).
  Supports: WCAG 1.3.1 (Info and Relationships).
  Example: A data table comparing pricing tiers needs column headers
  ("Plan," "Price," "Features") and, for complex tables, row headers
  too. Without proper headers, a screen reader reads each cell as
  isolated data with no context.

- Keep tables simple; avoid merged cells when possible.
  Supports: WCAG 1.3.1 (Info and Relationships).
  Example: If you must merge cells, ensure each data cell is still
  associated with the correct headers. When in doubt, break a complex
  table into two simpler ones.

- Provide a caption or summary for complex tables.
  Supports: WCAG 1.3.1 (Info and Relationships).

## Inclusive Language

- Use gender-neutral language.

- Avoid ableist terms (don't use "simply," "just," "easy"; these
  dismiss the reader's experience).

- Be specific rather than vague ("Select the file" not "Click the thing").
  Supports: WCAG 2.4.4 (Link Purpose in Context), general usability.

## Quick WCAG Reference

Key success criteria referenced in this checklist:

| Criterion | Name | What it covers |
|-----------|------|----------------|
| 1.1.1 | Non-text Content | Alt text for images, icons, controls |
| 1.2.1 | Audio/Video (Prerecorded) | Transcripts for audio, descriptions for video |
| 1.2.2 | Captions (Prerecorded) | Captions for video with audio |
| 1.3.1 | Info and Relationships | Headings, tables, lists convey structure programmatically |
| 1.4.1 | Use of Color | Don't use color as the only way to convey info |
| 1.4.3 | Contrast (Minimum) | 4.5:1 ratio for normal text, 3:1 for large text |
| 2.3.1 | Three Flashes | No content flashes more than 3 times per second |
| 2.4.4 | Link Purpose (In Context) | Link text describes where the link goes |
| 2.4.6 | Headings and Labels | Headings and labels describe topic or purpose |
| 3.1.3 | Unusual Words | Provide definitions for jargon or unusual terms |
| 3.1.4 | Abbreviations | Define abbreviations on first use |
| 3.1.5 | Reading Level | Content at lower secondary education reading level |
