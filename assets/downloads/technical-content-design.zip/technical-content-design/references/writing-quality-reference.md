# Writing Quality Reference

This reference contains detailed examples and avoidance lists used in
Steps 5 and 6 of SKILL.md. Read this file when drafting or reviewing
content to ensure the writing is high quality and doesn't read as
AI-generated.

## Good vs. Bad Patterns

These examples illustrate the difference between effective and ineffective
technical content. Use them as a compass, not a rigid template.

### Example 1: Help Article Instruction

**Bad:**
"The user should click on the Settings gear icon which can be found in the
upper-right corner of the application interface, and after doing so, they
should navigate to the Account section to find the option to change their
password, which will prompt them to enter their current and new passwords."

Why it's bad: One long sentence. Passive voice. Buries the action.
Uses "click on" (redundant). Doesn't use numbered steps.

**Good:**
"To change your password:
1. Select the **Settings** icon (gear) in the upper-right corner.
2. Select **Account**.
3. Select **Change password**.
4. Enter your current password, then enter your new password.
5. Select **Save**."

Why it's good: Numbered steps. One action per step. Starts each step
with a verb. Uses "select" consistently (device-agnostic). Bold for
UI elements.

### Example 2: Error Message (UI Microcopy)

**Bad:**
"Error: An unexpected error has occurred. Please try again later or contact
support. Error code: 0x80004005."

Why it's bad: Doesn't explain what happened. No actionable next step.
Error code is meaningless to most users.

**Good:**
"We couldn't save your changes. Check your internet connection and try again.
If this keeps happening, contact support (reference: SAVE-4005)."

Why it's good: Says what went wrong. Gives a next step. Provides a
human-readable reference code. Doesn't blame the user.

### Example 3: API Reference Description

**Bad:**
"This endpoint is used for getting the list of users that are in the system."

Why it's bad: Passive. Vague ("the system"). Wordy.

**Good:**
"Returns a paginated list of users in your organization."

Why it's good: Starts with the verb (what the endpoint does). Concise.
Specifies scope ("your organization"). Mentions pagination upfront.

### Example 4: Tone Shift — Same Feature, Different Audiences

**For end users:**
"You can invite teammates from the **Team** page. They'll get an email with
a link to join your workspace."

**For developers:**
"Use `POST /v1/invitations` to programmatically invite users. The endpoint
accepts an array of email addresses and returns invitation objects with
status tracking. See the Invitations API reference."

**For a PRD:**
"The invitation system supports both manual (UI) and programmatic (API)
workflows. Manual invitations are sent from the Team settings page.
Programmatic invitations use the /v1/invitations endpoint, enabling
bulk onboarding integrations."

---

## AI-Sounding Writing: Full Avoidance Guide

Content produced with this skill should read as though a knowledgeable human
wrote it. AI-generated text has recognizable patterns that erode trust and
credibility. Actively avoid these.

Reference: https://www.cherryleaf.com/2026/02/indicators-that-suggest-something-was-written-by-ai/

### Words and Phrases to Avoid

Do not use these unless the client style guide specifically includes them:

- "delve into," "deep dive," "navigate" (as metaphor), "at the heart of"
- "landscape," "ecosystem," "paradigm"
- "robust," "holistic," "nuanced," "multifaceted," "complex interplay"
- "it's worth noting," "it's important to remember"
- "leverage" (as a verb), "foster," "cultivate," "drive innovation"
- "seamless," "streamlined," "optimized"
- "tapestry," "mosaic," "fabric" (as metaphors for complexity)
- "in today's fast-paced world," "in an increasingly X world"
- "crucially," "moreover," "furthermore" (use "also" or restructure)
- "underscores the importance," "highlights the need"
- "at scale," "end-to-end," "best practices" (unless genuinely technical)
- "here's the thing," "here's an uncomfortable truth"

### Punctuation to Avoid

- **Don't use em dashes.** AI-generated text overuses em dashes as a
  substitute for commas, colons, parentheses, and periods. They become
  a crutch that makes every sentence feel the same. Use the punctuation
  mark that actually fits: a comma for a brief pause, a colon to introduce
  what follows, parentheses for a genuine aside, or a period to start a
  new sentence. If you find yourself reaching for an em dash, stop and ask
  which punctuation you're avoiding and why.

### Rhetorical Patterns to Break

- **Don't default to groups of three.** "Clear, concise, and actionable" is
  a cliché. Sometimes two items are enough. Sometimes five are needed.
  Vary your rhythm.
- **Don't force antithesis.** "Not just X, but Y" and "This isn't about A,
  it's about B" are overused framing devices. State your point directly
  instead of setting up contrasts.
- **Don't use rhetorical questions as transitions.** "Why does this matter?"
  followed by the answer you already wrote isn't engagement — it's a
  predictable pattern. Just make the point.
- **Don't over-signpost.** "This means several things" and "This requires
  three approaches" announce structure the reader can see for themselves.
  Trust the reader.

### Structural Habits to Avoid

- **Don't give every section equal length.** Real writing reflects the
  actual weight of ideas. Some topics deserve more space than others.
  Uniform paragraph and section lengths feel algorithmic.
- **Vary paragraph length aggressively.** A one-sentence paragraph hits
  hard. A five-sentence paragraph develops an idea. Alternating between
  short and long paragraphs creates rhythm and keeps the reader's eye
  moving. If you notice three or more consecutive paragraphs of similar
  length, break the pattern. This applies to sections too: a 50-word
  section followed by a 200-word section is fine if the ideas warrant it.
- **Don't hedge everything.** "Often," "typically," "generally," "can be,"
  and "may" in every other sentence sounds evasive. When you know something,
  state it. Qualify only when qualification is warranted.
- **Don't open with sweeping generalizations.** "In an era of digital
  transformation..." is empty. Start with something specific and concrete.
- **Vary sentence length and structure.** A mix of short and long sentences
  feels human. Uniform sentence length does not.

### The Self-Check

Before finalizing, scan the draft and ask:
- Could a reader guess this was AI-assisted from the word choices alone?
- Are there clusters of the flagged phrases above?
- Are there em dashes? Replace them with the appropriate punctuation.
- Does every list have exactly three items?
- Are there three or more consecutive paragraphs of similar length?
  Break the pattern.
- Is the hedging level appropriate, or is every claim softened?
- Does the opening paragraph say something specific, or could it
  introduce any article on any topic?

If the answer to any of these raises a concern, revise.
