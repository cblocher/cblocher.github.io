# Practitioners and Influences

This reference defines the practitioners whose thinking shapes how this
skill approaches content. These perspectives are not cited explicitly in
output — they inform decisions quietly. The goal is to produce work that
reflects these principles, not to lecture about them.

## Practitioners

- **Kristina Halvorson** — Content strategy as an organizational discipline.
  Every piece of content should exist for a reason, be maintained deliberately,
  and serve a defined audience and goal. If it doesn't earn its place, cut it.

- **Ann Rockley and Rahel Bailie** — Intelligent content and content
  operations. Content should be modular, semantically rich, and designed
  for reuse from the start. Rockley originated the concept of intelligent
  content — structured, semantically categorized, and therefore
  discoverable, reusable, and adaptable. Bailie operationalized it
  through content operations — the governance, processes, and workflows
  that make structured content sustainable at organizational scale.
  Together, they represent one principle: build content as a system, not
  a collection of pages.

- **Debbie Richards** — Instructional design grounded in evidence. Learning
  content should be designed around how people actually learn, with clear
  objectives, appropriate scaffolding, and measurable outcomes.

- **Jakob Nielsen** — Usability above all. Content must be scannable,
  task-oriented, and written for how people actually read on screens (which
  is to say: they don't read, they scan). Respect that.

- **Don Norman** — Human-centered design. The user's mental model matters
  more than the system's architecture. Write content that maps to how people
  think about their tasks, not how the software is built.

- **Conrad Gottfredson** — Performance support and the five moments of need.
  People need content when they're learning something new, learning more,
  trying to apply what they've learned, trying to fix something that went
  wrong, or adapting to change. Identify which moment you're writing for
  and design the content accordingly.

- **Val Swisher** — Global-ready content. Write with localization in mind
  from the start — controlled language, consistent terminology, culturally
  neutral phrasing. Content that can't travel is content that limits the
  product.

- **Tom Johnson** — API documentation and developer experience. Developer
  docs require the same care as user-facing content, with added emphasis
  on accuracy, working code examples, and respect for the developer's
  workflow. His work on I'd Rather Be Writing is a practical guide to
  doing this well.

- **Noz Urbina** — Content modeling, personalization, and omnichannel
  delivery. Content needs to be structured with rich metadata so it can
  be assembled, filtered, and delivered in the right format for the right
  person at the right moment — across channels, devices, and contexts.

- **Sarah O'Keefe** — Technical communication strategy and the business
  case for content. Content operations should be efficient, scalable, and
  aligned with business goals. Think about total cost of content ownership,
  not just the cost of creating it.

- **Michael Iantosca and Patrick Bosek** — Knowledge graphs, ontologies,
  and connected content. Content becomes far more powerful when its
  entities, relationships, and concepts are explicitly mapped using
  formal ontologies and knowledge graphs. Iantosca focuses on how
  knowledge graphs surface connections that flat taxonomies miss,
  enabling smarter search and content ecosystems that understand what
  they contain. Bosek applies ontological modeling to documentation
  systems specifically, making structured content machine-readable,
  interoperable, and capable of powering intelligent delivery — from
  dynamic assembly to AI-driven search.

- **Gloria Gery** — Electronic performance support and embedded assistance.
  The best help is the help users never have to go looking for. Content
  should be woven into the workflow — available at the point of need,
  in context, without forcing the user to leave their task. If someone
  has to open a separate help system, the product has already failed them
  at that moment.

- **Kelsie Harder** — The discipline of naming. Names carry meaning,
  set expectations, and shape how people think about what they're using.
  Naming a feature, a product, a category, or a UI element deserves the
  same rigor as any other content decision. A good name is clear, memorable,
  and honest about what the thing does. A bad name creates confusion that
  documentation has to clean up later. Get naming right early and you
  prevent terminology debt downstream.

- **Jonathon Colman** — Content design as a product discipline. Content
  isn't a service function that supports product teams — it is product
  work. Content designers should be embedded in product development from
  the start, shaping strategy and roadmaps alongside engineers and
  designers. His "do less, better" philosophy argues that deep engagement
  on fewer projects produces far greater impact than spreading thin across
  many. Championing the content practice means proving its value through
  the work, not fighting for a seat at the table after the decisions
  are already made.

- **Torrey Podmajersky** — Systematic UX writing integrated into the
  product process. UX content should follow repeatable, principled
  methods — not ad hoc wordsmithing at the end of a sprint. Her work
  provides frameworks for writing UI copy that is consistent, testable,
  and aligned with product goals from the design phase forward.

- **Benjamin Bloom** — Bloom's taxonomy of learning objectives. When
  creating instructional or educational content, structure it around
  what the learner should be able to do — not just what they should
  know. The progression from remembering to understanding to applying
  to analyzing to evaluating to creating provides a framework for
  designing content that meets learners where they are and moves them
  forward deliberately.

- **Michael Andrews** — AI, knowledge graphs, metadata, taxonomies,
  and structured content working together. His focus is on how machines
  consume and use content — making content not just human-readable but
  machine-readable. He bridges UX writing, information architecture,
  and the semantic structures that allow AI systems to find, understand,
  and deliver the right content in the right context.

- **Derek Featherstone** — Inclusive design and accessibility in
  practice. Accessibility isn't a checklist bolted on at the end — it's
  a design constraint that shapes better decisions from the start.
  When you design for people with disabilities, you design better
  experiences for everyone. His work grounds accessibility in real
  human scenarios, not abstract compliance.

- **Ginny Redish** — Plain language, writing for the web, and the
  usability of content itself. Content is a user interface. If people
  can't find, understand, and act on what you've written, the content
  has failed — regardless of how accurate or complete it is. Her work
  connects writing quality directly to usability testing and user
  research.

- **Abby Covert** — Information architecture and making sense of messes.
  Before you can write clear content, you need to understand the
  underlying structure — how things are organized, labeled, and
  connected. Her work focuses on the classification and arrangement
  of information as a deliberate design act, not something that just
  happens.

- **Colleen Jones** — Content measurement and proving content's value
  with data. Content work that can't demonstrate its impact is content
  work that gets cut. She provides frameworks for measuring content
  effectiveness, tying content decisions to business outcomes, and
  making the case for content investment with evidence, not intuition.

- **Edward Tufte** — Visual communication, data visualization, and
  information design. The clearest way to present complex information
  is often visual, not textual. His principles — maximize data-ink
  ratio, avoid chartjunk, respect the viewer's intelligence — apply
  to any content that involves data, comparisons, processes, or
  spatial relationships. When you can show instead of tell, show.

- **Harry Brignull** — Content ethics, deceptive patterns, and trust.
  Content designers shape the choices users see — button labels,
  opt-in defaults, cancellation flows, consent language, pricing
  presentation. Brignull coined the term "dark patterns" and has
  spent over a decade cataloging and exposing deceptive design
  practices. His work is a reminder that content can manipulate as
  easily as it can clarify. Every piece of UI copy is an ethical
  decision: does it help the user understand their options honestly,
  or does it steer them toward an outcome that benefits the business
  at their expense? Write content that builds trust, not content
  that exploits inattention.

- **Erika Hall** — Research, user insight, and asking the right
  questions. Before you write, you need to understand — and
  understanding comes from research, not assumptions. Her work
  focuses on making research practical, fast, and embedded in the
  design process rather than a separate phase that gets skipped
  when timelines shrink. For content, this means testing terminology
  with real users, validating that instructions actually work, and
  questioning whether the content you're about to create is solving
  the problem users actually have — not the problem the team assumed.

- **Lou Downe** — Service design and the end-to-end user journey.
  Content doesn't exist in isolation — it lives within a service
  that spans marketing, product, support, and customer success.
  Downe's 15 principles of good service design provide a framework
  for evaluating whether the entire experience works, not just
  individual touchpoints. For content, this means asking: can the
  user complete what they set out to do from start to finish? Does
  the language stay consistent across every channel they encounter?
  Do handoffs between teams create gaps where the user gets lost?
  Content often fails not within a single screen or article, but
  in the seams between them.

- **Mary Hubbard** — Developer relations, developer experience, and
  building content ecosystems for technical audiences. DevRel content
  goes beyond API docs — it includes developer onboarding, community
  education, technical blogs, sample applications, and the broader
  experience of learning and building with a platform. When your
  product has a developer audience, the content strategy must account
  for how developers learn (by doing, not reading), how they evaluate
  tools (through working examples and honest documentation of
  limitations), and how community-generated content fits alongside
  official docs.

## Emerging Disciplines

Two areas are important to this skill but are too young or distributed
to be represented by a single established practitioner:

- **AI and content** — Writing for LLMs, prompt design, structuring
  content so AI systems can retrieve and use it accurately, and using
  AI tools responsibly in the content workflow. This field is evolving
  rapidly. The skill addresses this through Step 3 (Make Content
  AI-Ready), but no single practitioner has yet defined the discipline
  the way Halvorson defined content strategy or Nielsen defined web
  usability. Stay current with practitioners like Michael Andrews,
  Noz Urbina, and Patrick Bosek, whose work increasingly addresses
  AI's intersection with structured content.

- **Content governance at scale** — Managing content quality,
  consistency, and lifecycle across large organizations with hundreds
  of contributors and thousands of content assets. O'Keefe and Bailie
  cover significant ground here, but governance at true enterprise
  scale — with automated workflows, content scoring, and distributed
  authoring — is an area where practices are still being codified.
  The skill addresses this through Phase 1 (Discovery & Strategy)
  and Phase 6 (Operate & Maintain) in the Content Type Catalog.
